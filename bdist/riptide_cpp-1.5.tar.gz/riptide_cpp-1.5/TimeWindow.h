#pragma once

#include "CommonInc.h"

PyObject *
TimeWindow(PyObject *self, PyObject *args);