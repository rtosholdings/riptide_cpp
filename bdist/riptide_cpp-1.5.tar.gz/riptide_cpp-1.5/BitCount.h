#pragma once
PyObject * BitCount(PyObject *self, PyObject *args);
