#pragma once

PyObject *
BasicMathHook(PyObject *self, PyObject *args);
