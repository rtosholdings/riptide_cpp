#pragma once


PyObject *
BasicMathTwoInputs(PyObject *self, PyObject *args);

PyObject *
BasicMathTwoInputsFromNumber(PyObject* input1, PyObject* input2, PyObject* output, INT64 funcNumber);

PyObject *
Where(PyObject *self, PyObject *args);
