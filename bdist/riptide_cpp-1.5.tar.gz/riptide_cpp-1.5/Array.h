#pragma once

PyObject *
AsAnyArray(PyObject *self, PyObject *args, PyObject *kwargs);

PyObject *
AsFastArray(PyObject *self, PyObject *args, PyObject *kwargs);