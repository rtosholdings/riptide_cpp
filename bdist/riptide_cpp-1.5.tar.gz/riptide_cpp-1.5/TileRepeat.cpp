#include "RipTide.h"
#include "ndarray.h"
#include "MathWorker.h"

#include "CommonInc.h"

//#define LOGGING printf
#define LOGGING(...)


PyObject *
ToBeDone(PyObject *self, PyObject *args, PyObject *kwargs) {
   return NULL;
}
